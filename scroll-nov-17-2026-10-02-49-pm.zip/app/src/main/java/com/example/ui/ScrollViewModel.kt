package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ScrollPreferencesRepository
import com.example.data.ScrollStateBus
import com.example.model.FeedScrollStyle
import com.example.model.FirstUploadSpeed
import com.example.model.OrbSize
import com.example.model.ScrollEngineState
import com.example.model.ScrollMode
import com.example.model.ScrollSettings
import com.example.service.PermissionHelper
import com.example.service.ScrollOverlayService
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ScrollViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ScrollPreferencesRepository(application)

    val settings: StateFlow<ScrollSettings> = repository.settingsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = ScrollSettings()
        )

    val engineState: StateFlow<ScrollEngineState> = ScrollStateBus.engineState

    init {
        viewModelScope.launch {
            repository.settingsFlow.collectLatest { loaded ->
                ScrollStateBus.updateSettings(loaded)
            }
        }
        refreshPermissions()
    }

    fun refreshPermissions() {
        val ctx = getApplication<Application>()
        ScrollStateBus.setPermissions(
            overlayGranted = PermissionHelper.isOverlayPermissionGranted(ctx),
            notificationGranted = PermissionHelper.isNotificationPermissionGranted(ctx),
            accessibilityEnabled = PermissionHelper.isAccessibilityServiceEnabled(ctx)
        )
    }

    fun toggleOverlay(requestNotificationPermission: () -> Unit) {
        val ctx = getApplication<Application>()
        refreshPermissions()

        if (!PermissionHelper.isOverlayPermissionGranted(ctx)) {
            PermissionHelper.openOverlaySettings(ctx)
            return
        }

        if (!PermissionHelper.isNotificationPermissionGranted(ctx)) {
            requestNotificationPermission()
        }

        if (engineState.value.isOverlayVisible) {
            ScrollOverlayService.stopOverlay(ctx)
        } else {
            ScrollOverlayService.startOverlay(ctx)
        }
    }

    fun stopActiveScroll() {
        ScrollStateBus.stopScrolling("Gulir dihentikan")
    }

    fun triggerModeInApp(mode: ScrollMode) {
        val ctx = getApplication<Application>()
        if (!PermissionHelper.isAccessibilityServiceEnabled(ctx)) {
            PermissionHelper.openAccessibilitySettings(ctx)
            return
        }
        ScrollStateBus.startMode(mode)
    }

    fun setFirstUploadSpeed(speed: FirstUploadSpeed) {
        viewModelScope.launch { repository.setFirstUploadSpeed(speed) }
    }

    fun setSmartBottomStop(enabled: Boolean) {
        viewModelScope.launch { repository.setSmartBottomStop(enabled) }
    }

    fun setFeedScrollStyle(style: FeedScrollStyle) {
        viewModelScope.launch { repository.setFeedScrollStyle(style) }
    }

    fun setFeedIntervalSeconds(seconds: Float) {
        viewModelScope.launch { repository.setFeedIntervalSeconds(seconds) }
    }

    fun setOrbSize(size: OrbSize) {
        viewModelScope.launch { repository.setOrbSize(size) }
    }

    fun setOrbIdleOpacity(opacity: Float) {
        viewModelScope.launch { repository.setOrbIdleOpacity(opacity) }
    }

    fun setSnapToEdge(enabled: Boolean) {
        viewModelScope.launch { repository.setSnapToEdge(enabled) }
    }
}
