package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.FeedScrollStyle
import com.example.model.FirstUploadSpeed
import com.example.model.OrbSize
import com.example.model.ScrollSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.scrollDataStore: DataStore<Preferences> by preferencesDataStore(name = "scroll_preferences")

class ScrollPreferencesRepository(private val context: Context) {

    private object Keys {
        val FIRST_UPLOAD_SPEED = stringPreferencesKey("first_upload_speed")
        val SMART_BOTTOM_STOP = booleanPreferencesKey("smart_bottom_stop")
        val FEED_SCROLL_STYLE = stringPreferencesKey("feed_scroll_style")
        val FEED_INTERVAL_SECONDS = floatPreferencesKey("feed_interval_seconds")
        val ORB_SIZE = stringPreferencesKey("orb_size")
        val ORB_IDLE_OPACITY = floatPreferencesKey("orb_idle_opacity")
        val SNAP_TO_EDGE = booleanPreferencesKey("snap_to_edge")
        val OVERLAY_X = intPreferencesKey("overlay_x")
        val OVERLAY_Y = intPreferencesKey("overlay_y")
    }

    val settingsFlow: Flow<ScrollSettings> = context.scrollDataStore.data.map { prefs ->
        val speed = prefs[Keys.FIRST_UPLOAD_SPEED]?.let { name ->
            runCatching { FirstUploadSpeed.valueOf(name) }.getOrNull()
        } ?: FirstUploadSpeed.FAST

        val style = prefs[Keys.FEED_SCROLL_STYLE]?.let { name ->
            runCatching { FeedScrollStyle.valueOf(name) }.getOrNull()
        } ?: FeedScrollStyle.SMOOTH_FEED

        val orbSize = prefs[Keys.ORB_SIZE]?.let { name ->
            runCatching { OrbSize.valueOf(name) }.getOrNull()
        } ?: OrbSize.MEDIUM

        ScrollSettings(
            firstUploadSpeed = speed,
            smartBottomStop = prefs[Keys.SMART_BOTTOM_STOP] ?: true,
            feedScrollStyle = style,
            feedIntervalSeconds = (prefs[Keys.FEED_INTERVAL_SECONDS] ?: 3.0f).coerceIn(1.5f, 8.0f),
            orbSize = orbSize,
            orbIdleOpacity = (prefs[Keys.ORB_IDLE_OPACITY] ?: 0.72f).coerceIn(0.35f, 1.0f),
            snapToEdge = prefs[Keys.SNAP_TO_EDGE] ?: false,
            overlayX = prefs[Keys.OVERLAY_X] ?: 40,
            overlayY = prefs[Keys.OVERLAY_Y] ?: 360
        )
    }

    suspend fun setFirstUploadSpeed(speed: FirstUploadSpeed) {
        context.scrollDataStore.edit { it[Keys.FIRST_UPLOAD_SPEED] = speed.name }
    }

    suspend fun setSmartBottomStop(enabled: Boolean) {
        context.scrollDataStore.edit { it[Keys.SMART_BOTTOM_STOP] = enabled }
    }

    suspend fun setFeedScrollStyle(style: FeedScrollStyle) {
        context.scrollDataStore.edit { it[Keys.FEED_SCROLL_STYLE] = style.name }
    }

    suspend fun setFeedIntervalSeconds(seconds: Float) {
        context.scrollDataStore.edit { it[Keys.FEED_INTERVAL_SECONDS] = seconds.coerceIn(1.5f, 8.0f) }
    }

    suspend fun setOrbSize(size: OrbSize) {
        context.scrollDataStore.edit { it[Keys.ORB_SIZE] = size.name }
    }

    suspend fun setOrbIdleOpacity(opacity: Float) {
        context.scrollDataStore.edit { it[Keys.ORB_IDLE_OPACITY] = opacity.coerceIn(0.35f, 1.0f) }
    }

    suspend fun setSnapToEdge(enabled: Boolean) {
        context.scrollDataStore.edit { it[Keys.SNAP_TO_EDGE] = enabled }
    }

    suspend fun saveOverlayPosition(x: Int, y: Int) {
        context.scrollDataStore.edit {
            it[Keys.OVERLAY_X] = x
            it[Keys.OVERLAY_Y] = y
        }
    }
}
