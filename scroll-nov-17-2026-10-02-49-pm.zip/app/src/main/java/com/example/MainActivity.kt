package com.example

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DynamicFeed
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.rounded.DynamicFeed
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.ScrollViewModel
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.SandboxFeedScreen
import com.example.ui.theme.ScrollTheme

private enum class ScrollTab(val label: String) {
    CONTROL("Kontrol"),
    SANDBOX("Uji Coba")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ScrollTheme {
                ScrollAppRoot()
            }
        }
    }
}

@Composable
private fun ScrollAppRoot(
    viewModel: ScrollViewModel = viewModel()
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val engineState by viewModel.engineState.collectAsStateWithLifecycle()
    var selectedTab by rememberSaveable { mutableStateOf(ScrollTab.CONTROL) }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) {
        viewModel.refreshPermissions()
    }

    val requestNotifications = {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        viewModel.refreshPermissions()
    }

    if (selectedTab != ScrollTab.CONTROL) {
        BackHandler {
            selectedTab = ScrollTab.CONTROL
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 840.dp

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = MaterialTheme.colorScheme.background,
            contentWindowInsets = WindowInsets.safeDrawing,
            bottomBar = {
                if (!useRail) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface
                    ) {
                        ScrollTab.entries.forEach { tab ->
                            val selected = selectedTab == tab
                            NavigationBarItem(
                                selected = selected,
                                onClick = { selectedTab = tab },
                                icon = {
                                    Icon(
                                        imageVector = when (tab) {
                                            ScrollTab.CONTROL -> if (selected) Icons.Rounded.Tune else Icons.Outlined.Tune
                                            ScrollTab.SANDBOX -> if (selected) Icons.Rounded.DynamicFeed else Icons.Outlined.DynamicFeed
                                        },
                                        contentDescription = tab.label
                                    )
                                },
                                label = { Text(tab.label) },
                                modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surface
                    ) {
                        Spacer(modifier = Modifier.weight(1f))
                        ScrollTab.entries.forEach { tab ->
                            val selected = selectedTab == tab
                            NavigationRailItem(
                                selected = selected,
                                onClick = { selectedTab = tab },
                                icon = {
                                    Icon(
                                        imageVector = when (tab) {
                                            ScrollTab.CONTROL -> if (selected) Icons.Rounded.Tune else Icons.Outlined.Tune
                                            ScrollTab.SANDBOX -> if (selected) Icons.Rounded.DynamicFeed else Icons.Outlined.DynamicFeed
                                        },
                                        contentDescription = tab.label
                                    )
                                },
                                label = { Text(tab.label) },
                                modifier = Modifier.testTag("rail_tab_${tab.name.lowercase()}")
                            )
                        }
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }

                when (selectedTab) {
                    ScrollTab.CONTROL -> {
                        DashboardScreen(
                            settings = settings,
                            engineState = engineState,
                            onToggleOverlay = {
                                viewModel.toggleOverlay(requestNotifications)
                            },
                            onStopActiveScroll = viewModel::stopActiveScroll,
                            onRequestNotificationPermission = requestNotifications,
                            onFirstUploadSpeedChange = viewModel::setFirstUploadSpeed,
                            onSmartBottomStopChange = viewModel::setSmartBottomStop,
                            onFeedScrollStyleChange = viewModel::setFeedScrollStyle,
                            onFeedIntervalChange = viewModel::setFeedIntervalSeconds,
                            onOrbSizeChange = viewModel::setOrbSize,
                            onOrbOpacityChange = viewModel::setOrbIdleOpacity,
                            onSnapToEdgeChange = viewModel::setSnapToEdge,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    ScrollTab.SANDBOX -> {
                        SandboxFeedScreen(
                            engineState = engineState,
                            onToggleOverlay = {
                                viewModel.toggleOverlay(requestNotifications)
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}
