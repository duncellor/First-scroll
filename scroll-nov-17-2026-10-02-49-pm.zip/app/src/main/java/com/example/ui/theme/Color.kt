package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ObsidianBg = Color(0xFF070B14)
val ObsidianSurface = Color(0xFF0F1626)
val ObsidianSurfaceVariant = Color(0xFF182238)
val ObsidianCardBorder = Color(0xFF25324D)

val ElectricCyan = Color(0xFF38BDF8)
val ElectricCyanContainer = Color(0xFF0C354D)
val IndigoAccent = Color(0xFF818CF8)
val IndigoContainer = Color(0xFF262A56)
val EmeraldPulse = Color(0xFF10B981)
val EmeraldContainer = Color(0xFF0B3B2E)
val AmberGlow = Color(0xFFF59E0B)
val AmberContainer = Color(0xFF422C0A)
val RoseAlert = Color(0xFFF43F5E)

val LightBg = Color(0xFFF4F7FB)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE8EEF7)
val LightPrimary = Color(0xFF0284C7)
val LightPrimaryContainer = Color(0xFFE0F2FE)
val LightSecondary = Color(0xFF4F46E5)
val LightSecondaryContainer = Color(0xFFE0E7FF)
val LightTertiary = Color(0xFF059669)
val LightTertiaryContainer = Color(0xFFD1FAE5)
