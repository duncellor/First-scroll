package com.example.service

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.SweepGradient
import android.view.View
import android.view.animation.LinearInterpolator
import com.example.model.ScrollMode
import kotlin.math.min

/**
 * Custom Canvas-rendered AssistiveTouch-inspired floating orb view.
 * Lightweight, smooth at 60fps across any app, with pulsing active state rings.
 */
class AssistiveOrbView(context: Context) : View(context) {

    var activeMode: ScrollMode = ScrollMode.IDLE
        set(value) {
            if (field != value) {
                field = value
                updateAnimationState()
                invalidate()
            }
        }

    var isPressedState: Boolean = false
        set(value) {
            if (field != value) {
                field = value
                invalidate()
            }
        }

    private var pulsePhase = 0f
    private val pulseAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1600L
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            pulsePhase = it.animatedValue as Float
            invalidate()
        }
    }

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
    }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val stopSquarePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
    }
    private val activeRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val chevronPath = Path()

    private fun updateAnimationState() {
        if (activeMode == ScrollMode.IDLE) {
            if (pulseAnimator.isRunning) pulseAnimator.cancel()
            pulsePhase = 0f
        } else {
            if (!pulseAnimator.isRunning) pulseAnimator.start()
        }
    }

    override fun onDetachedFromWindow() {
        pulseAnimator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val minDim = min(width, height).toFloat()
        val outerRadius = minDim * 0.44f

        val scale = if (isPressedState) 0.92f else 1.0f
        canvas.save()
        canvas.scale(scale, scale, cx, cy)

        // 1. Dark glassmorphic sphere body
        bgPaint.shader = RadialGradient(
            cx - outerRadius * 0.2f,
            cy - outerRadius * 0.25f,
            outerRadius * 1.3f,
            intArrayOf(
                Color.argb(235, 30, 41, 59),
                Color.argb(238, 11, 18, 36)
            ),
            null,
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, outerRadius, bgPaint)

        // 2. Specular outer border
        borderPaint.strokeWidth = minDim * 0.025f
        borderPaint.color = when (activeMode) {
            ScrollMode.IDLE -> Color.argb(120, 226, 232, 240)
            ScrollMode.TO_FIRST_UPLOAD -> Color.argb(210, 56, 189, 248)
            ScrollMode.AUTO_FEED -> Color.argb(210, 16, 185, 129)
        }
        canvas.drawCircle(cx, cy, outerRadius - borderPaint.strokeWidth / 2f, borderPaint)

        // 3. AssistiveTouch concentric inner rings
        if (activeMode == ScrollMode.IDLE) {
            ringPaint.color = Color.argb(38, 255, 255, 255)
            canvas.drawCircle(cx, cy, outerRadius * 0.74f, ringPaint)

            ringPaint.color = Color.argb(65, 255, 255, 255)
            canvas.drawCircle(cx, cy, outerRadius * 0.56f, ringPaint)

            ringPaint.color = Color.argb(235, 248, 250, 252)
            canvas.drawCircle(cx, cy, outerRadius * 0.38f, ringPaint)

            // Crisp miniature double chevron inside the core orb
            iconPaint.color = Color.rgb(11, 18, 36)
            iconPaint.strokeWidth = minDim * 0.045f
            val arrowW = outerRadius * 0.16f
            val arrowH = outerRadius * 0.09f
            chevronPath.reset()
            chevronPath.moveTo(cx - arrowW, cy - arrowH * 0.9f)
            chevronPath.lineTo(cx, cy + arrowH * 0.1f)
            chevronPath.lineTo(cx + arrowW, cy - arrowH * 0.9f)
            chevronPath.moveTo(cx - arrowW, cy + arrowH * 0.25f)
            chevronPath.lineTo(cx, cy + arrowH * 1.25f)
            chevronPath.lineTo(cx + arrowW, cy + arrowH * 0.25f)
            canvas.drawPath(chevronPath, iconPaint)
        } else {
            val accentColor = if (activeMode == ScrollMode.TO_FIRST_UPLOAD) {
                Color.rgb(56, 189, 248)
            } else {
                Color.rgb(16, 185, 129)
            }

            // Pulsing halo ring
            val pulseRadius = outerRadius * (0.58f + pulsePhase * 0.34f)
            val pulseAlpha = ((1f - pulsePhase) * 140f).toInt().coerceIn(0, 255)
            activeRingPaint.strokeWidth = minDim * 0.04f
            activeRingPaint.shader = null
            activeRingPaint.color = Color.argb(
                pulseAlpha,
                Color.red(accentColor),
                Color.green(accentColor),
                Color.blue(accentColor)
            )
            canvas.drawCircle(cx, cy, pulseRadius, activeRingPaint)

            // Rotating sweep ring
            canvas.save()
            canvas.rotate(pulsePhase * 360f, cx, cy)
            activeRingPaint.strokeWidth = minDim * 0.055f
            activeRingPaint.shader = SweepGradient(
                cx,
                cy,
                intArrayOf(
                    Color.TRANSPARENT,
                    accentColor,
                    Color.WHITE
                ),
                floatArrayOf(0.1f, 0.7f, 1.0f)
            )
            canvas.drawCircle(cx, cy, outerRadius * 0.72f, activeRingPaint)
            canvas.restore()

            // Center stop square icon (tap to stop!)
            ringPaint.color = Color.argb(55, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor))
            canvas.drawCircle(cx, cy, outerRadius * 0.45f, ringPaint)

            val halfSquare = outerRadius * 0.17f
            val corner = halfSquare * 0.35f
            canvas.drawRoundRect(
                cx - halfSquare,
                cy - halfSquare,
                cx + halfSquare,
                cy + halfSquare,
                corner,
                corner,
                stopSquarePaint
            )
        }

        canvas.restore()
    }
}
