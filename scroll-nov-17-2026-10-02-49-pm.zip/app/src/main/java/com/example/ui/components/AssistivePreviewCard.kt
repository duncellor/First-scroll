package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.KeyboardDoubleArrowDown
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.example.model.OrbSize
import com.example.model.ScrollMode
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldPulse
import com.example.ui.theme.IndigoAccent
import kotlin.math.roundToInt

/**
 * Interactive AssistiveTouch Orb playground inside the app.
 * Users can drag the miniature orb freely and tap it to preview the 2-option menu.
 */
@Composable
fun AssistiveOrbPlayground(
    orbSize: OrbSize,
    idleOpacity: Float,
    activeMode: ScrollMode,
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current
    var showPreviewMenu by remember { mutableStateOf(false) }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .height(196.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF13223F),
                        Color(0xFF0A101E)
                    )
                )
            )
            .border(
                width = 1.dp,
                color = Color(0xFF243454),
                shape = RoundedCornerShape(22.dp)
            )
    ) {
        val maxWidthPx = with(density) { maxWidth.toPx() }
        val maxHeightPx = with(density) { maxHeight.toPx() }
        val orbPx = with(density) { orbSize.sizeDp.dp.toPx() }
        val marginPx = with(density) { 14.dp.toPx() }

        var offsetX by remember(maxWidthPx, orbPx) {
            mutableFloatStateOf((maxWidthPx * 0.14f).coerceIn(marginPx, (maxWidthPx - orbPx - marginPx).coerceAtLeast(marginPx)))
        }
        var offsetY by remember(maxHeightPx, orbPx) {
            mutableFloatStateOf(((maxHeightPx - orbPx) / 2f).coerceIn(marginPx, (maxHeightPx - orbPx - marginPx).coerceAtLeast(marginPx)))
        }

        // Decorative subtle grid dots to evoke a phone screen surface
        Canvas(modifier = Modifier.fillMaxSize()) {
            val step = 28.dp.toPx()
            var x = step
            while (x < size.width) {
                var y = step
                while (y < size.height) {
                    drawCircle(
                        color = Color.White.copy(alpha = 0.045f),
                        radius = 1.4.dp.toPx(),
                        center = Offset(x, y)
                    )
                    y += step
                }
                x += step
            }
        }

        // Helper hint at top-right
        Text(
            text = "Geser atau ketuk bola",
            style = MaterialTheme.typography.labelSmall,
            color = Color(0xFF94A3B8),
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(horizontal = 14.dp, vertical = 10.dp)
        )

        // Interactive menu preview anchored opposite the orb
        AnimatedVisibility(
            visible = showPreviewMenu,
            enter = fadeIn() + scaleIn(initialScale = 0.92f),
            exit = fadeOut() + scaleOut(targetScale = 0.92f),
            modifier = Modifier
                .align(
                    if (offsetX < maxWidthPx / 2f) Alignment.CenterEnd else Alignment.CenterStart
                )
                .padding(horizontal = 14.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = Color(0xEC0D1528),
                tonalElevation = 8.dp,
                modifier = Modifier
                    .width(214.dp)
                    .border(1.dp, Color(0x4538BDF8), RoundedCornerShape(18.dp))
            ) {
                Column(
                    modifier = Modifier.padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    PreviewOptionPill(
                        title = "1. Scroll Paling Bawah",
                        subtitle = "First upload",
                        accent = ElectricCyan,
                        icon = {
                            Icon(
                                imageVector = Icons.Rounded.KeyboardDoubleArrowDown,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        onClick = { showPreviewMenu = false }
                    )
                    PreviewOptionPill(
                        title = "2. Gulir Feed Otomatis",
                        subtitle = "Auto-scroll feed",
                        accent = EmeraldPulse,
                        icon = {
                            Icon(
                                imageVector = Icons.Rounded.PlayArrow,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        onClick = { showPreviewMenu = false }
                    )
                }
            }
        }

        // Draggable AssistiveTouch Orb
        val displayAlpha = if (activeMode != ScrollMode.IDLE || showPreviewMenu) 1f else idleOpacity
        Box(
            modifier = Modifier
                .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
                .size(orbSize.sizeDp.dp)
                .alpha(displayAlpha)
                .clip(CircleShape)
                .testTag("preview_assistive_orb")
                .pointerInput(maxWidthPx, maxHeightPx, orbPx) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        offsetX = (offsetX + dragAmount.x).coerceIn(
                            marginPx,
                            (maxWidthPx - orbPx - marginPx).coerceAtLeast(marginPx)
                        )
                        offsetY = (offsetY + dragAmount.y).coerceIn(
                            marginPx,
                            (maxHeightPx - orbPx - marginPx).coerceAtLeast(marginPx)
                        )
                    }
                }
                .clickable { showPreviewMenu = !showPreviewMenu }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val radius = size.minDimension / 2f
                val center = Offset(size.width / 2f, size.height / 2f)

                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0xFF1E293B), Color(0xFF0B1224)),
                        center = Offset(center.x - radius * 0.2f, center.y - radius * 0.2f),
                        radius = radius * 1.25f
                    ),
                    radius = radius
                )
                drawCircle(
                    color = when (activeMode) {
                        ScrollMode.TO_FIRST_UPLOAD -> ElectricCyan
                        ScrollMode.AUTO_FEED -> EmeraldPulse
                        ScrollMode.IDLE -> Color.White.copy(alpha = 0.48f)
                    },
                    radius = radius - 1.5.dp.toPx(),
                    style = Stroke(width = 1.5.dp.toPx())
                )
                drawCircle(
                    color = Color.White.copy(alpha = 0.16f),
                    radius = radius * 0.74f
                )
                drawCircle(
                    color = Color.White.copy(alpha = 0.28f),
                    radius = radius * 0.55f
                )
                drawCircle(
                    color = Color(0xFFF8FAFC),
                    radius = radius * 0.36f
                )

                val w = radius * 0.16f
                val h = radius * 0.09f
                val chevron = Path().apply {
                    moveTo(center.x - w, center.y - h * 0.9f)
                    lineTo(center.x, center.y + h * 0.1f)
                    lineTo(center.x + w, center.y - h * 0.9f)
                    moveTo(center.x - w, center.y + h * 0.25f)
                    lineTo(center.x, center.y + h * 1.25f)
                    lineTo(center.x + w, center.y + h * 0.25f)
                }
                drawPath(
                    path = chevron,
                    color = Color(0xFF0B1224),
                    style = Stroke(
                        width = 2.dp.toPx(),
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round
                    )
                )
            }
        }
    }
}

@Composable
private fun PreviewOptionPill(
    title: String,
    subtitle: String,
    accent: Color,
    icon: @Composable () -> Unit,
    onClick: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(accent.copy(alpha = 0.16f))
            .border(1.dp, accent.copy(alpha = 0.42f), RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(
                    Brush.linearGradient(
                        colors = listOf(accent, IndigoAccent)
                    )
                )
        ) {
            icon()
        }
        Spacer(modifier = Modifier.width(8.dp))
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                color = Color.White
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = Color(0xFFCBD5E1)
            )
        }
    }
}
