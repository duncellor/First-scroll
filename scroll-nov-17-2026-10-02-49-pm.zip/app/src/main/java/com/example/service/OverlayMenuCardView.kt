package com.example.service

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Compact dark glassmorphic floating menu shown when the user taps the Scroll orb.
 * Presents the 2 primary scroll choices + quick accessibility warning if disabled.
 */
class OverlayMenuCardView(
    context: Context,
    isAccessibilityEnabled: Boolean,
    onSelectFirstUpload: () -> Unit,
    onSelectAutoFeed: () -> Unit,
    onOpenAccessibilitySettings: () -> Unit,
    onOpenApp: () -> Unit,
    onHideOverlay: () -> Unit,
    onDismissMenu: () -> Unit
) : LinearLayout(context) {

    init {
        orientation = VERTICAL
        val pad = dp(14)
        setPadding(pad, pad, pad, pad)
        elevation = dp(16).toFloat()

        background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(24).toFloat()
            setColor(Color.argb(242, 12, 18, 34))
            setStroke(dp(1), Color.argb(72, 148, 163, 184))
        }

        // Header Row
        val header = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, dp(2), dp(10))
        }

        val titleView = TextView(context).apply {
            text = "Scroll"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTypeface(Typeface.DEFAULT_BOLD)
            layoutParams = LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
        }

        val badgeView = TextView(context).apply {
            text = if (isAccessibilityEnabled) "SIAP" else "BUTUH IZIN"
            setTextColor(
                if (isAccessibilityEnabled) Color.rgb(52, 211, 153) else Color.rgb(251, 191, 36)
            )
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            setTypeface(Typeface.DEFAULT_BOLD)
            setPadding(dp(8), dp(3), dp(8), dp(3))
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(
                    if (isAccessibilityEnabled) Color.argb(42, 16, 185, 129)
                    else Color.argb(48, 245, 158, 11)
                )
            }
        }

        val closeBtn = TextView(context).apply {
            text = "✕"
            setTextColor(Color.rgb(148, 163, 184))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            gravity = Gravity.CENTER
            minWidth = dp(36)
            minHeight = dp(36)
            setOnClickListener { onDismissMenu() }
        }

        header.addView(titleView)
        header.addView(badgeView)
        header.addView(closeBtn)
        addView(header)

        if (!isAccessibilityEnabled) {
            val warningCard = buildActionRow(
                badgeText = "!",
                badgeColor = Color.rgb(245, 158, 11),
                cardBgColor = Color.argb(45, 245, 158, 11),
                cardStrokeColor = Color.argb(110, 245, 158, 11),
                title = "Aktifkan Aksesibilitas",
                subtitle = "Diperlukan agar Scroll bisa menggulir aplikasi lain",
                onClick = onOpenAccessibilitySettings
            )
            addView(warningCard)
            addSpacer(dp(8))
        }

        // Option 1: Scroll Paling Bawah (First Upload)
        addView(
            buildActionRow(
                badgeText = "⇣",
                badgeColor = Color.rgb(56, 189, 248),
                cardBgColor = Color.argb(38, 56, 189, 248),
                cardStrokeColor = Color.argb(95, 56, 189, 248),
                title = "1. Scroll Paling Bawah",
                subtitle = "Menuju unggahan pertama (First Upload)",
                onClick = onSelectFirstUpload
            )
        )

        addSpacer(dp(8))

        // Option 2: Gulir Feed Otomatis
        addView(
            buildActionRow(
                badgeText = "▶",
                badgeColor = Color.rgb(16, 185, 129),
                cardBgColor = Color.argb(36, 16, 185, 129),
                cardStrokeColor = Color.argb(95, 16, 185, 129),
                title = "2. Gulir Feed Otomatis",
                subtitle = "Scroll otomatis konten feed media sosial",
                onClick = onSelectAutoFeed
            )
        )

        addSpacer(dp(10))

        // Footer quick actions
        val footer = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val openAppBtn = TextView(context).apply {
            text = "Pengaturan"
            setTextColor(Color.rgb(148, 163, 184))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setTypeface(Typeface.DEFAULT_BOLD)
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
            layoutParams = LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(Color.argb(26, 255, 255, 255))
            }
            setOnClickListener { onOpenApp() }
        }

        val gap = View(context).apply {
            layoutParams = LayoutParams(dp(8), 1)
        }

        val hideBtn = TextView(context).apply {
            text = "Tutup Bola"
            setTextColor(Color.rgb(251, 113, 133))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setTypeface(Typeface.DEFAULT_BOLD)
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
            layoutParams = LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(Color.argb(28, 244, 63, 94))
            }
            setOnClickListener { onHideOverlay() }
        }

        footer.addView(openAppBtn)
        footer.addView(gap)
        footer.addView(hideBtn)
        addView(footer)
    }

    private fun buildActionRow(
        badgeText: String,
        badgeColor: Int,
        cardBgColor: Int,
        cardStrokeColor: Int,
        title: String,
        subtitle: String,
        onClick: () -> Unit
    ): View {
        val row = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(11), dp(12), dp(11))
            minimumHeight = dp(56)
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(cardBgColor)
                setStroke(dp(1), cardStrokeColor)
            }
            setOnClickListener { onClick() }
        }

        val badge = TextView(context).apply {
            text = badgeText
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTypeface(Typeface.DEFAULT_BOLD)
            gravity = Gravity.CENTER
            layoutParams = LayoutParams(dp(36), dp(36)).apply {
                marginEnd = dp(12)
            }
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(badgeColor)
            }
        }

        val textColumn = LinearLayout(context).apply {
            orientation = VERTICAL
            layoutParams = LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
        }

        val titleTv = TextView(context).apply {
            text = title
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTypeface(Typeface.DEFAULT_BOLD)
        }

        val subtitleTv = TextView(context).apply {
            text = subtitle
            setTextColor(Color.rgb(186, 198, 214))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            setPadding(0, dp(2), 0, 0)
        }

        textColumn.addView(titleTv)
        textColumn.addView(subtitleTv)

        row.addView(badge)
        row.addView(textColumn)
        return row
    }

    private fun addSpacer(heightPx: Int) {
        addView(View(context).apply {
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, heightPx)
        })
    }

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
    }
}
