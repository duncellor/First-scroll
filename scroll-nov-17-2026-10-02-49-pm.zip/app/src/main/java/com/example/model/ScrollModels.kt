package com.example.model

enum class ScrollMode {
    IDLE,
    TO_FIRST_UPLOAD,
    AUTO_FEED
}

enum class FirstUploadSpeed(
    val label: String,
    val swipeDurationMs: Long,
    val pauseBetweenMs: Long
) {
    NORMAL("Normal", swipeDurationMs = 280L, pauseBetweenMs = 220L),
    FAST("Cepat", swipeDurationMs = 190L, pauseBetweenMs = 130L),
    TURBO("Turbo", swipeDurationMs = 130L, pauseBetweenMs = 75L)
}

enum class FeedScrollStyle(
    val label: String,
    val subtitle: String,
    val startYRatio: Float,
    val endYRatio: Float,
    val swipeDurationMs: Long
) {
    SMOOTH_FEED(
        label = "Baca Feed Halus",
        subtitle = "Gulir bertahap untuk membaca postingan IG, X, Threads, FB",
        startYRatio = 0.68f,
        endYRatio = 0.34f,
        swipeDurationMs = 520L
    ),
    SHORT_VIDEO(
        label = "Video Pendek / Reels",
        subtitle = "Swipe vertikal cepat untuk TikTok, Reels, YouTube Shorts",
        startYRatio = 0.76f,
        endYRatio = 0.24f,
        swipeDurationMs = 220L
    )
}

enum class OrbSize(val label: String, val sizeDp: Int) {
    SMALL("Kecil", 48),
    MEDIUM("Sedang", 58),
    LARGE("Besar", 68)
}

data class ScrollSettings(
    val firstUploadSpeed: FirstUploadSpeed = FirstUploadSpeed.FAST,
    val smartBottomStop: Boolean = true,
    val feedScrollStyle: FeedScrollStyle = FeedScrollStyle.SMOOTH_FEED,
    val feedIntervalSeconds: Float = 3.0f,
    val orbSize: OrbSize = OrbSize.MEDIUM,
    val orbIdleOpacity: Float = 0.72f,
    val snapToEdge: Boolean = false,
    val overlayX: Int = 40,
    val overlayY: Int = 360
)

data class ScrollEngineState(
    val isOverlayVisible: Boolean = false,
    val activeMode: ScrollMode = ScrollMode.IDLE,
    val scrollCount: Int = 0,
    val statusMessage: String? = null,
    val isAccessibilityConnected: Boolean = false,
    val isOverlayPermissionGranted: Boolean = false,
    val isNotificationPermissionGranted: Boolean = true
)
