package com.example.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.example.data.ScrollStateBus
import com.example.model.ScrollMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.random.Random

class ScrollAccessibilityService : AccessibilityService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var scrollJob: Job? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        ScrollStateBus.setAccessibilityConnected(true)

        serviceScope.launch {
            ScrollStateBus.engineState
                .map { it.activeMode }
                .distinctUntilChanged()
                .collectLatest { mode ->
                    scrollJob?.cancel()
                    scrollJob = null
                    when (mode) {
                        ScrollMode.TO_FIRST_UPLOAD -> {
                            scrollJob = serviceScope.launch { runScrollToFirstUpload() }
                        }
                        ScrollMode.AUTO_FEED -> {
                            scrollJob = serviceScope.launch { runAutoFeedScroll() }
                        }
                        ScrollMode.IDLE -> Unit
                    }
                }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Events kept lightweight; gestures drive cross-app scrolling universally.
    }

    override fun onInterrupt() {
        scrollJob?.cancel()
        ScrollStateBus.stopScrolling("Layanan aksesibilitas terganggu")
    }

    override fun onDestroy() {
        scrollJob?.cancel()
        serviceScope.cancel()
        ScrollStateBus.setAccessibilityConnected(false)
        ScrollStateBus.stopScrolling()
        super.onDestroy()
    }

    private suspend fun runScrollToFirstUpload() {
        var lastSignature = captureViewportSignature()
        var unchangedStreak = 0

        while (serviceScope.isActive && ScrollStateBus.engineState.value.activeMode == ScrollMode.TO_FIRST_UPLOAD) {
            val settings = ScrollStateBus.settings.value
            val speed = settings.firstUploadSpeed

            val (width, height) = getScreenDimensions()
            // Slight horizontal jitter avoids rigid single-pixel taps while staying centered
            val x = width * (0.48f + Random.nextFloat() * 0.04f)
            val startY = height * 0.78f
            val endY = height * 0.22f

            val completed = dispatchSwipeGesture(
                startX = x,
                startY = startY,
                endX = x,
                endY = endY,
                durationMs = speed.swipeDurationMs
            )

            if (!completed) {
                delay(250L)
                continue
            }

            ScrollStateBus.incrementScrollCount()
            delay(speed.pauseBetweenMs)

            if (settings.smartBottomStop) {
                val currentSignature = captureViewportSignature()
                if (currentSignature.isNotEmpty() && currentSignature == lastSignature) {
                    unchangedStreak++
                    // Give lazy-loading social media grids extra time on streak 3 & 4
                    if (unchangedStreak in 3..4) {
                        delay(750L)
                    }
                    if (unchangedStreak >= 6) {
                        ScrollStateBus.stopScrolling("Mencapai unggahan paling bawah!")
                        break
                    }
                } else {
                    unchangedStreak = 0
                    lastSignature = currentSignature
                }
            }
        }
    }

    private suspend fun runAutoFeedScroll() {
        while (serviceScope.isActive && ScrollStateBus.engineState.value.activeMode == ScrollMode.AUTO_FEED) {
            val settings = ScrollStateBus.settings.value
            val style = settings.feedScrollStyle
            val (width, height) = getScreenDimensions()

            val x = width * (0.49f + Random.nextFloat() * 0.02f)
            val startY = height * style.startYRatio
            val endY = height * style.endYRatio

            val completed = dispatchSwipeGesture(
                startX = x,
                startY = startY,
                endX = x,
                endY = endY,
                durationMs = style.swipeDurationMs
            )

            if (completed) {
                ScrollStateBus.incrementScrollCount()
            }

            val waitMs = (settings.feedIntervalSeconds * 1000L).toLong().coerceAtLeast(800L)
            delay(waitMs)
        }
    }

    private suspend fun dispatchSwipeGesture(
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float,
        durationMs: Long
    ): Boolean = suspendCancellableCoroutine { continuation ->
        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs.coerceAtLeast(60L))
        val gesture = GestureDescription.Builder()
            .addStroke(stroke)
            .build()

        val callback = object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                if (continuation.isActive) continuation.resume(true)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                if (continuation.isActive) continuation.resume(false)
            }
        }

        val accepted = dispatchGesture(gesture, callback, null)
        if (!accepted && continuation.isActive) {
            continuation.resume(false)
        }
    }

    private fun getScreenDimensions(): Pair<Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = wm.currentWindowMetrics.bounds
            bounds.width().coerceAtLeast(360) to bounds.height().coerceAtLeast(640)
        } else {
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(metrics)
            metrics.widthPixels.coerceAtLeast(360) to metrics.heightPixels.coerceAtLeast(640)
        }
    }

    /**
     * Captures a compact fingerprint of visible scrollable items in the active window
     * to detect when a profile grid or feed has hit its very last (oldest) post.
     */
    private fun captureViewportSignature(): String {
        val root = try {
            rootInActiveWindow
        } catch (_: Exception) {
            null
        } ?: return ""

        val sb = StringBuilder()
        var visited = 0
        val rect = Rect()

        fun traverse(node: AccessibilityNodeInfo?, depth: Int) {
            if (node == null || depth > 6 || visited >= 45) return
            visited++
            val text = node.text?.toString()?.take(24)
            val desc = node.contentDescription?.toString()?.take(24)
            if (!text.isNullOrBlank() || !desc.isNullOrBlank() || node.isScrollable) {
                node.getBoundsInScreen(rect)
                sb.append(node.className?.toString()?.substringAfterLast('.') ?: "")
                sb.append(':')
                sb.append(rect.top)
                sb.append(',')
                sb.append(rect.bottom)
                sb.append(':')
                if (!text.isNullOrBlank()) sb.append(text)
                if (!desc.isNullOrBlank()) sb.append(desc)
                sb.append('|')
            }
            val count = node.childCount.coerceAtMost(12)
            for (i in 0 until count) {
                val child = node.getChild(i)
                traverse(child, depth + 1)
            }
        }

        try {
            traverse(root, 0)
        } catch (_: Exception) {
            return ""
        }
        return sb.toString()
    }
}
