package com.example.data

import com.example.model.ScrollEngineState
import com.example.model.ScrollMode
import com.example.model.ScrollSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * Coordinates real-time state between the Jetpack Compose UI,
 * the floating WindowManager overlay service, and the AccessibilityService.
 */
object ScrollStateBus {

    private val _engineState = MutableStateFlow(ScrollEngineState())
    val engineState: StateFlow<ScrollEngineState> = _engineState.asStateFlow()

    private val _settings = MutableStateFlow(ScrollSettings())
    val settings: StateFlow<ScrollSettings> = _settings.asStateFlow()

    fun updateSettings(newSettings: ScrollSettings) {
        _settings.value = newSettings
    }

    fun setOverlayVisible(visible: Boolean) {
        _engineState.update { state ->
            state.copy(
                isOverlayVisible = visible,
                activeMode = if (!visible) ScrollMode.IDLE else state.activeMode
            )
        }
    }

    fun setAccessibilityConnected(connected: Boolean) {
        _engineState.update { it.copy(isAccessibilityConnected = connected) }
    }

    fun setPermissions(overlayGranted: Boolean, notificationGranted: Boolean, accessibilityEnabled: Boolean) {
        _engineState.update {
            it.copy(
                isOverlayPermissionGranted = overlayGranted,
                isNotificationPermissionGranted = notificationGranted,
                isAccessibilityConnected = it.isAccessibilityConnected || accessibilityEnabled
            )
        }
    }

    fun startMode(mode: ScrollMode) {
        _engineState.update {
            it.copy(
                activeMode = mode,
                scrollCount = 0,
                statusMessage = when (mode) {
                    ScrollMode.TO_FIRST_UPLOAD -> "Menggulir ke unggahan pertama..."
                    ScrollMode.AUTO_FEED -> "Gulir feed otomatis aktif"
                    ScrollMode.IDLE -> null
                }
            )
        }
    }

    fun stopScrolling(reason: String? = null) {
        _engineState.update {
            it.copy(
                activeMode = ScrollMode.IDLE,
                statusMessage = reason
            )
        }
    }

    fun incrementScrollCount() {
        _engineState.update {
            it.copy(scrollCount = it.scrollCount + 1)
        }
    }

    fun clearStatusMessage() {
        _engineState.update { it.copy(statusMessage = null) }
    }
}
