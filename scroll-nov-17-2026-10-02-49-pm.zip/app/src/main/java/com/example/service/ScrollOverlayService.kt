package com.example.service

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.ScrollPreferencesRepository
import com.example.data.ScrollStateBus
import com.example.model.ScrollMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlin.math.abs

class ScrollOverlayService : Service() {

    companion object {
        const val ACTION_SHOW = "com.example.action.SHOW_OVERLAY"
        const val ACTION_HIDE = "com.example.action.HIDE_OVERLAY"
        const val ACTION_STOP_SCROLL = "com.example.action.STOP_SCROLL"

        private const val CHANNEL_ID = "scroll_overlay_channel"
        private const val NOTIFICATION_ID = 4091

        fun startOverlay(context: Context) {
            val intent = Intent(context, ScrollOverlayService::class.java).apply {
                action = ACTION_SHOW
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopOverlay(context: Context) {
            val intent = Intent(context, ScrollOverlayService::class.java).apply {
                action = ACTION_HIDE
            }
            context.startService(intent)
        }
    }

    private lateinit var windowManager: WindowManager
    private lateinit var preferencesRepository: ScrollPreferencesRepository
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private var orbView: AssistiveOrbView? = null
    private var orbParams: WindowManager.LayoutParams? = null

    private var menuBackdropView: FrameLayout? = null
    private var menuCardView: OverlayMenuCardView? = null

    private var idleDimJob: Job? = null
    private var lastToastMessage: String? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        preferencesRepository = ScrollPreferencesRepository(applicationContext)
        createNotificationChannel()
        observeState()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_HIDE -> {
                ScrollStateBus.stopScrolling()
                removeOverlayViews()
                ScrollStateBus.setOverlayVisible(false)
                stopForegroundCompat()
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_STOP_SCROLL -> {
                ScrollStateBus.stopScrolling("Gulir dihentikan")
            }
            else -> {
                if (!PermissionHelper.isOverlayPermissionGranted(this)) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                startForegroundCompat()
                showOrbIfNeeded()
                ScrollStateBus.setOverlayVisible(true)
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        idleDimJob?.cancel()
        removeOverlayViews()
        ScrollStateBus.stopScrolling()
        ScrollStateBus.setOverlayVisible(false)
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun observeState() {
        serviceScope.launch {
            ScrollStateBus.settings.collectLatest { settings ->
                val orb = orbView ?: return@collectLatest
                val params = orbParams ?: return@collectLatest
                val targetPx = dp(settings.orbSize.sizeDp)
                if (params.width != targetPx || params.height != targetPx) {
                    params.width = targetPx
                    params.height = targetPx
                    runCatching { windowManager.updateViewLayout(orb, params) }
                }
                if (ScrollStateBus.engineState.value.activeMode == ScrollMode.IDLE && menuCardView == null) {
                    orb.alpha = settings.orbIdleOpacity
                } else {
                    orb.alpha = 1f
                }
            }
        }

        serviceScope.launch {
            ScrollStateBus.engineState.collectLatest { state ->
                val orb = orbView
                if (orb != null) {
                    orb.activeMode = state.activeMode
                    if (state.activeMode != ScrollMode.IDLE) {
                        idleDimJob?.cancel()
                        orb.alpha = 1f
                    } else if (menuCardView == null) {
                        scheduleIdleDim()
                    }
                }

                val msg = state.statusMessage
                if (msg != null && msg != lastToastMessage && state.activeMode == ScrollMode.IDLE) {
                    lastToastMessage = msg
                    Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT).show()
                    ScrollStateBus.clearStatusMessage()
                } else if (msg == null) {
                    lastToastMessage = null
                }
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun showOrbIfNeeded() {
        if (orbView != null) return

        val settings = ScrollStateBus.settings.value
        val sizePx = dp(settings.orbSize.sizeDp)
        val (screenW, screenH) = getScreenSize()

        val initialX = settings.overlayX.coerceIn(0, (screenW - sizePx).coerceAtLeast(0))
        val initialY = settings.overlayY.coerceIn(dp(24), (screenH - sizePx - dp(24)).coerceAtLeast(dp(24)))

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            sizePx,
            sizePx,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = initialX
            y = initialY
        }

        val orb = AssistiveOrbView(this).apply {
            activeMode = ScrollStateBus.engineState.value.activeMode
            alpha = settings.orbIdleOpacity
        }

        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        var startRawX = 0f
        var startRawY = 0f
        var startParamX = 0
        var startParamY = 0
        var isDragging = false

        orb.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    idleDimJob?.cancel()
                    orb.alpha = 1f
                    orb.isPressedState = true
                    startRawX = event.rawX
                    startRawY = event.rawY
                    startParamX = params.x
                    startParamY = params.y
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - startRawX).toInt()
                    val dy = (event.rawY - startRawY).toInt()
                    if (!isDragging && (abs(dx) > touchSlop || abs(dy) > touchSlop)) {
                        isDragging = true
                        dismissMenu()
                    }
                    if (isDragging) {
                        val (w, h) = getScreenSize()
                        params.x = (startParamX + dx).coerceIn(0, (w - params.width).coerceAtLeast(0))
                        params.y = (startParamY + dy).coerceIn(dp(12), (h - params.height - dp(12)).coerceAtLeast(dp(12)))
                        runCatching { windowManager.updateViewLayout(orb, params) }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    orb.isPressedState = false
                    if (isDragging) {
                        if (ScrollStateBus.settings.value.snapToEdge) {
                            snapOrbToNearestEdge(orb, params)
                        } else {
                            persistPosition(params.x, params.y)
                        }
                        scheduleIdleDim()
                    } else if (event.actionMasked == MotionEvent.ACTION_UP) {
                        onOrbTapped()
                    }
                    true
                }
                else -> false
            }
        }

        orbView = orb
        orbParams = params
        windowManager.addView(orb, params)
        scheduleIdleDim()
    }

    private fun onOrbTapped() {
        val currentMode = ScrollStateBus.engineState.value.activeMode
        if (currentMode != ScrollMode.IDLE) {
            ScrollStateBus.stopScrolling("Gulir dihentikan")
            scheduleIdleDim()
            return
        }

        if (menuCardView != null) {
            dismissMenu()
        } else {
            showMenuPopup()
        }
    }

    private fun showMenuPopup() {
        val orb = orbView ?: return
        val oParams = orbParams ?: return
        dismissMenu()

        idleDimJob?.cancel()
        orb.alpha = 1f

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        // Transparent backdrop to close menu on outside tap
        val backdrop = FrameLayout(this).apply {
            setOnClickListener { dismissMenu() }
        }
        val backdropParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )

        val accessibilityReady = PermissionHelper.isAccessibilityServiceEnabled(this)

        val card = OverlayMenuCardView(
            context = this,
            isAccessibilityEnabled = accessibilityReady,
            onSelectFirstUpload = {
                dismissMenu()
                if (PermissionHelper.isAccessibilityServiceEnabled(this)) {
                    ScrollStateBus.startMode(ScrollMode.TO_FIRST_UPLOAD)
                } else {
                    Toast.makeText(
                        this,
                        "Aktifkan layanan aksesibilitas Scroll terlebih dahulu",
                        Toast.LENGTH_SHORT
                    ).show()
                    PermissionHelper.openAccessibilitySettings(this)
                }
            },
            onSelectAutoFeed = {
                dismissMenu()
                if (PermissionHelper.isAccessibilityServiceEnabled(this)) {
                    ScrollStateBus.startMode(ScrollMode.AUTO_FEED)
                } else {
                    Toast.makeText(
                        this,
                        "Aktifkan layanan aksesibilitas Scroll terlebih dahulu",
                        Toast.LENGTH_SHORT
                    ).show()
                    PermissionHelper.openAccessibilitySettings(this)
                }
            },
            onOpenAccessibilitySettings = {
                dismissMenu()
                PermissionHelper.openAccessibilitySettings(this)
            },
            onOpenApp = {
                dismissMenu()
                val intent = Intent(this, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                }
                startActivity(intent)
            },
            onHideOverlay = {
                dismissMenu()
                stopOverlay(this)
            },
            onDismissMenu = { dismissMenu() }
        )

        val menuWidth = dp(264)
        val estimatedMenuHeight = if (accessibilityReady) dp(250) else dp(320)
        val (screenW, screenH) = getScreenSize()
        val margin = dp(12)

        val orbCenterX = oParams.x + oParams.width / 2
        val orbCenterY = oParams.y + oParams.height / 2

        val menuX = if (orbCenterX < screenW / 2) {
            (oParams.x + oParams.width + dp(10)).coerceAtMost(screenW - menuWidth - margin)
        } else {
            (oParams.x - menuWidth - dp(10)).coerceAtLeast(margin)
        }.coerceIn(margin, (screenW - menuWidth - margin).coerceAtLeast(margin))

        val menuY = if (orbCenterY + estimatedMenuHeight + margin < screenH) {
            oParams.y.coerceAtLeast(dp(36))
        } else {
            (oParams.y + oParams.height - estimatedMenuHeight).coerceAtLeast(dp(36))
        }

        val cardParams = WindowManager.LayoutParams(
            menuWidth,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = menuX
            y = menuY
        }

        card.alpha = 0f
        card.scaleX = 0.92f
        card.scaleY = 0.92f

        windowManager.addView(backdrop, backdropParams)
        windowManager.addView(card, cardParams)

        card.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(170L)
            .setInterpolator(DecelerateInterpolator())
            .start()

        menuBackdropView = backdrop
        menuCardView = card
    }

    private fun dismissMenu() {
        menuCardView?.let { card ->
            runCatching { windowManager.removeView(card) }
        }
        menuBackdropView?.let { backdrop ->
            runCatching { windowManager.removeView(backdrop) }
        }
        menuCardView = null
        menuBackdropView = null
        scheduleIdleDim()
    }

    private fun snapOrbToNearestEdge(orb: View, params: WindowManager.LayoutParams) {
        val (screenW, _) = getScreenSize()
        val targetX = if (params.x + params.width / 2 < screenW / 2) {
            dp(8)
        } else {
            (screenW - params.width - dp(8)).coerceAtLeast(0)
        }
        val startX = params.x
        ValueAnimator.ofInt(startX, targetX).apply {
            duration = 200L
            interpolator = DecelerateInterpolator()
            addUpdateListener { anim ->
                params.x = anim.animatedValue as Int
                runCatching { windowManager.updateViewLayout(orb, params) }
            }
            start()
        }
        persistPosition(targetX, params.y)
    }

    private fun persistPosition(x: Int, y: Int) {
        serviceScope.launch {
            preferencesRepository.saveOverlayPosition(x, y)
        }
    }

    private fun scheduleIdleDim() {
        idleDimJob?.cancel()
        val orb = orbView ?: return
        if (ScrollStateBus.engineState.value.activeMode != ScrollMode.IDLE || menuCardView != null) {
            orb.alpha = 1f
            return
        }
        idleDimJob = serviceScope.launch {
            delay(2400L)
            if (ScrollStateBus.engineState.value.activeMode == ScrollMode.IDLE && menuCardView == null) {
                orb.animate()
                    .alpha(ScrollStateBus.settings.value.orbIdleOpacity)
                    .setDuration(280L)
                    .start()
            }
        }
    }

    private fun removeOverlayViews() {
        dismissMenu()
        orbView?.let { orb ->
            runCatching { windowManager.removeView(orb) }
        }
        orbView = null
        orbParams = null
    }

    private fun getScreenSize(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = windowManager.currentWindowMetrics.bounds
            bounds.width().coerceAtLeast(360) to bounds.height().coerceAtLeast(640)
        } else {
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealMetrics(metrics)
            metrics.widthPixels.coerceAtLeast(360) to metrics.heightPixels.coerceAtLeast(640)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_text)
                setShowBadge(false)
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val hideIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, ScrollOverlayService::class.java).apply { action = ACTION_HIDE },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setContentIntent(openAppIntent)
            .setOngoing(true)
            .setSilent(true)
            .addAction(0, "Tutup Overlay", hideIntent)
            .build()
    }

    private fun startForegroundCompat() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun stopForegroundCompat() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
    }

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
    }
}
