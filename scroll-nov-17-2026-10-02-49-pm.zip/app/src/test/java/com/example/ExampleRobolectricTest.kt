package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.ScrollStateBus
import com.example.model.ScrollMode
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app name string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Scroll", appName)
    }

    @Test
    fun `scroll state bus transitions between modes and resets count`() {
        ScrollStateBus.setOverlayVisible(true)
        ScrollStateBus.startMode(ScrollMode.TO_FIRST_UPLOAD)
        ScrollStateBus.incrementScrollCount()
        ScrollStateBus.incrementScrollCount()

        assertEquals(ScrollMode.TO_FIRST_UPLOAD, ScrollStateBus.engineState.value.activeMode)
        assertEquals(2, ScrollStateBus.engineState.value.scrollCount)

        ScrollStateBus.startMode(ScrollMode.AUTO_FEED)
        assertEquals(ScrollMode.AUTO_FEED, ScrollStateBus.engineState.value.activeMode)
        assertEquals(0, ScrollStateBus.engineState.value.scrollCount)

        ScrollStateBus.stopScrolling("Selesai")
        assertEquals(ScrollMode.IDLE, ScrollStateBus.engineState.value.activeMode)
        assertEquals("Selesai", ScrollStateBus.engineState.value.statusMessage)
    }
}
