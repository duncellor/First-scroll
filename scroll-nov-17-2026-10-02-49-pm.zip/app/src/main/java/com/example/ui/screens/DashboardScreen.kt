package com.example.ui.screens

import android.os.Build
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.TouchApp
import androidx.compose.material.icons.rounded.AccessibilityNew
import androidx.compose.material.icons.rounded.AutoAwesomeMotion
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.KeyboardDoubleArrowDown
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.FeedScrollStyle
import com.example.model.FirstUploadSpeed
import com.example.model.OrbSize
import com.example.model.ScrollEngineState
import com.example.model.ScrollMode
import com.example.model.ScrollSettings
import com.example.service.PermissionHelper
import com.example.ui.components.AssistiveOrbPlayground
import com.example.ui.theme.AmberGlow
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldPulse
import com.example.ui.theme.IndigoAccent
import java.util.Locale
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DashboardScreen(
    settings: ScrollSettings,
    engineState: ScrollEngineState,
    onToggleOverlay: () -> Unit,
    onStopActiveScroll: () -> Unit,
    onRequestNotificationPermission: () -> Unit,
    onFirstUploadSpeedChange: (FirstUploadSpeed) -> Unit,
    onSmartBottomStopChange: (Boolean) -> Unit,
    onFeedScrollStyleChange: (FeedScrollStyle) -> Unit,
    onFeedIntervalChange: (Float) -> Unit,
    onOrbSizeChange: (OrbSize) -> Unit,
    onOrbOpacityChange: (Float) -> Unit,
    onSnapToEdgeChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val allCorePermissionsReady =
        engineState.isOverlayPermissionGranted && engineState.isAccessibilityConnected

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 600.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header + Live Status Pill
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Scroll",
                            style = MaterialTheme.typography.displaySmall,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "Tombol mengambang lintas media sosial",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    StatusBadgePill(
                        isOverlayVisible = engineState.isOverlayVisible,
                        activeMode = engineState.activeMode,
                        scrollCount = engineState.scrollCount
                    )
                }
            }

            // Hero Card: Interactive AssistiveTouch Orb Preview + Primary Overlay Toggle
            item {
                Surface(
                    shape = RoundedCornerShape(26.dp),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 3.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            width = 1.dp,
                            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.6f),
                            shape = RoundedCornerShape(26.dp)
                        )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        AssistiveOrbPlayground(
                            orbSize = settings.orbSize,
                            idleOpacity = settings.orbIdleOpacity,
                            activeMode = engineState.activeMode
                        )

                        Button(
                            onClick = onToggleOverlay,
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (engineState.isOverlayVisible) {
                                    MaterialTheme.colorScheme.surfaceVariant
                                } else {
                                    MaterialTheme.colorScheme.primary
                                },
                                contentColor = if (engineState.isOverlayVisible) {
                                    MaterialTheme.colorScheme.onSurface
                                } else {
                                    MaterialTheme.colorScheme.onPrimary
                                }
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("toggle_overlay_button")
                        ) {
                            Icon(
                                imageVector = if (engineState.isOverlayVisible) {
                                    Icons.Rounded.VisibilityOff
                                } else {
                                    Icons.Rounded.Visibility
                                },
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = when {
                                    !engineState.isOverlayPermissionGranted -> "Izinkan & Munculkan Overlay"
                                    engineState.isOverlayVisible -> "Sembunyikan Tombol Overlay"
                                    else -> "Munculkan Tombol Overlay"
                                },
                                style = MaterialTheme.typography.labelLarge
                            )
                        }

                        AnimatedVisibility(visible = engineState.activeMode != ScrollMode.IDLE) {
                            FilledTonalButton(
                                onClick = onStopActiveScroll,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("stop_active_scroll_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Stop,
                                    contentDescription = null,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Hentikan Gulir (${engineState.scrollCount}x)",
                                    style = MaterialTheme.typography.labelLarge
                                )
                            }
                        }
                    }
                }
            }

            // Permissions Checklist Card
            item {
                if (allCorePermissionsReady && engineState.isNotificationPermissionGranted) {
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = EmeraldPulse.copy(alpha = 0.12f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                1.dp,
                                EmeraldPulse.copy(alpha = 0.35f),
                                RoundedCornerShape(18.dp)
                            )
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.CheckCircle,
                                contentDescription = "Semua izin aktif",
                                tint = EmeraldPulse,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "Semua izin siap! Aktifkan bola mengambang lalu buka IG, TikTok, X, atau YouTube.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                } else {
                    SectionCard(
                        title = "Izin Diperlukan",
                        subtitle = "Aktifkan izin agar bola mengambang bisa menggulir di aplikasi mana saja",
                        icon = Icons.Rounded.AccessibilityNew,
                        accent = AmberGlow
                    ) {
                        PermissionRow(
                            title = "1. Tampil di Atas Aplikasi",
                            subtitle = "Agar bola mengambang muncul di atas IG, TikTok, X, dll.",
                            granted = engineState.isOverlayPermissionGranted,
                            icon = Icons.Outlined.Layers,
                            testTag = "permission_overlay_button",
                            onClick = { PermissionHelper.openOverlaySettings(context) }
                        )

                        PermissionRow(
                            title = "2. Layanan Aksesibilitas",
                            subtitle = "Melakukan gestur gulir otomatis ke bawah / feed.",
                            granted = engineState.isAccessibilityConnected,
                            icon = Icons.Outlined.TouchApp,
                            testTag = "permission_accessibility_button",
                            onClick = { PermissionHelper.openAccessibilitySettings(context) }
                        )

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                            !engineState.isNotificationPermissionGranted
                        ) {
                            PermissionRow(
                                title = "3. Izin Notifikasi (Opsional)",
                                subtitle = "Menampilkan kontrol cepat saat overlay aktif.",
                                granted = false,
                                icon = Icons.Outlined.Notifications,
                                testTag = "permission_notification_button",
                                onClick = onRequestNotificationPermission
                            )
                        }
                    }
                }
            }

            // Mode 1 Settings: Scroll Paling Bawah (First Upload)
            item {
                SectionCard(
                    title = "Opsi 1 • Scroll Paling Bawah",
                    subtitle = "Lompat cepat menuju unggahan pertama (First Upload)",
                    icon = Icons.Rounded.KeyboardDoubleArrowDown,
                    accent = ElectricCyan
                ) {
                    Text(
                        text = "Kecepatan Gulir",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FirstUploadSpeed.entries.forEach { speed ->
                            FilterChip(
                                selected = settings.firstUploadSpeed == speed,
                                onClick = { onFirstUploadSpeedChange(speed) },
                                label = { Text(speed.label) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ElectricCyan.copy(alpha = 0.2f),
                                    selectedLabelColor = MaterialTheme.colorScheme.primary
                                ),
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("speed_chip_${speed.name.lowercase()}")
                            )
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .clickable { onSmartBottomStopChange(!settings.smartBottomStop) }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                            Text(
                                text = "Berhenti Otomatis di Bawah",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Deteksi otomatis saat tidak ada unggahan lebih lama lagi",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = settings.smartBottomStop,
                            onCheckedChange = onSmartBottomStopChange,
                            modifier = Modifier.testTag("smart_bottom_stop_switch")
                        )
                    }
                }
            }

            // Mode 2 Settings: Gulir Feed Otomatis
            item {
                SectionCard(
                    title = "Opsi 2 • Gulir Feed Otomatis",
                    subtitle = "Nikmati feed media sosial tanpa menyentuh layar terus-menerus",
                    icon = Icons.Rounded.PlayArrow,
                    accent = EmeraldPulse
                ) {
                    Text(
                        text = "Gaya Gulir",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        FeedScrollStyle.entries.forEach { style ->
                            val selected = settings.feedScrollStyle == style
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(
                                        if (selected) EmeraldPulse.copy(alpha = 0.14f)
                                        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                                    )
                                    .border(
                                        width = 1.dp,
                                        color = if (selected) EmeraldPulse.copy(alpha = 0.6f)
                                        else Color.Transparent,
                                        shape = RoundedCornerShape(14.dp)
                                    )
                                    .clickable { onFeedScrollStyleChange(style) }
                                    .padding(horizontal = 14.dp, vertical = 12.dp)
                                    .testTag("feed_style_${style.name.lowercase()}")
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (selected) EmeraldPulse
                                            else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                                        )
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = style.label,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = style.subtitle,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Jeda Antar Gulir",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = String.format(Locale.US, "%.1f dtk", settings.feedIntervalSeconds),
                            style = MaterialTheme.typography.labelMedium,
                            color = EmeraldPulse
                        )
                    }

                    Slider(
                        value = settings.feedIntervalSeconds,
                        onValueChange = { raw ->
                            val snapped = (raw * 2f).roundToInt() / 2f
                            onFeedIntervalChange(snapped)
                        },
                        valueRange = 1.5f..8.0f,
                        modifier = Modifier.testTag("feed_interval_slider")
                    )
                }
            }

            // Floating Orb Appearance Settings
            item {
                SectionCard(
                    title = "Tampilan Bola Mengambang",
                    subtitle = "Sesuaikan ukuran, transparansi, dan perilaku geser bola",
                    icon = Icons.Rounded.Tune,
                    accent = IndigoAccent
                ) {
                    Text(
                        text = "Ukuran Bola",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OrbSize.entries.forEach { size ->
                            FilterChip(
                                selected = settings.orbSize == size,
                                onClick = { onOrbSizeChange(size) },
                                label = { Text("${size.label} (${size.sizeDp}dp)") },
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("orb_size_${size.name.lowercase()}")
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Transparansi Saat Diam",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${(settings.orbIdleOpacity * 100).roundToInt()}%",
                            style = MaterialTheme.typography.labelMedium,
                            color = IndigoAccent
                        )
                    }

                    Slider(
                        value = settings.orbIdleOpacity,
                        onValueChange = onOrbOpacityChange,
                        valueRange = 0.35f..1.0f,
                        modifier = Modifier.testTag("orb_opacity_slider")
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .clickable { onSnapToEdgeChange(!settings.snapToEdge) }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                            Text(
                                text = "Tempel Otomatis ke Tepi Layar",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Matikan agar bola tetap di titik mana pun Anda meletakkan",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = settings.snapToEdge,
                            onCheckedChange = onSnapToEdgeChange,
                            modifier = Modifier.testTag("snap_to_edge_switch")
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}

@Composable
private fun StatusBadgePill(
    isOverlayVisible: Boolean,
    activeMode: ScrollMode,
    scrollCount: Int
) {
    val (label, color) = when {
        activeMode == ScrollMode.TO_FIRST_UPLOAD -> "First Upload • ${scrollCount}x" to ElectricCyan
        activeMode == ScrollMode.AUTO_FEED -> "Auto Feed • ${scrollCount}x" to EmeraldPulse
        isOverlayVisible -> "Overlay Aktif" to EmeraldPulse
        else -> "Siap" to Color(0xFF94A3B8)
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.14f))
            .border(1.dp, color.copy(alpha = 0.4f), RoundedCornerShape(50))
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = color
        )
    }
}

@Composable
private fun SectionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accent: Color,
    content: @Composable () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp,
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.45f),
                shape = RoundedCornerShape(22.dp)
            )
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            Brush.linearGradient(
                                colors = listOf(accent.copy(alpha = 0.25f), accent.copy(alpha = 0.08f))
                            )
                        )
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accent,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            content()
        }
    }
}

@Composable
private fun PermissionRow(
    title: String,
    subtitle: String,
    granted: Boolean,
    icon: ImageVector,
    testTag: String,
    onClick: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(
                if (granted) EmeraldPulse.copy(alpha = 0.1f)
                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            )
            .clickable(enabled = !granted, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 12.dp)
            .testTag(testTag)
    ) {
        Icon(
            imageVector = if (granted) Icons.Rounded.CheckCircle else icon,
            contentDescription = null,
            tint = if (granted) EmeraldPulse else AmberGlow,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = if (granted) "Aktif" else "Atur",
            style = MaterialTheme.typography.labelLarge,
            color = if (granted) EmeraldPulse else MaterialTheme.colorScheme.primary
        )
    }
}
